# Install
```
pip install zeka
```
